<html>
<body style="background-color:red">

<?php 
   $id = $_GET['id'];
   include('auth.php');
   if ($id == $auth) { ?>

<div id="login">
<h1> login </h1> 

  <form action="index.php" method="post">
     <input type="text" name="user" placeholder="enter username">
     <input type="text" name="pass" placeholder="enter password">
     <input type="hidden" name="id" value="<?php echo $id; ?>">
     <input type="submit" value="login">
   </form>
</div>
<div id="register">
  <h1> register </h1>
   <form action="register.php" method="post">
      <input type="text" name="user" placeholder="enter username">
     <input type="text" name="pass" placeholder="enter password">
     <input type="hidden" name="id" value="<?php echo $id; ?>">
     <input type="submit" value="register">


<?php } 
   else { //doe something   
                } 
                ?>

</body>
</html>




