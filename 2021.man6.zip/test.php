<?php 
    include('copy.php');
      $source = "/opt/lampp/htdocs/conf";
      $dist = "/opt/lampp/htdocs/hello";
     // copy_check($source,$dist); 
      echo "work";
      $a = scandir($dist);
      foreach ($a as $b) { 

      $s = "$source/$b";
      $d = "$dist/$b";
      copy_all($s,$d); 
  echo "work";
}
?> 
