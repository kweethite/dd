<?php 
include("config.php");
function copy_check($source,$dist) {
   
$dir = scandir($source);
foreach ($dir as $sru) { 
   @mkdir("$dist/$sru");
   



}//end foreach

}//end fun

//ramdom string fucn for user 
 function randomstring()
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randstring = '';
        for ($i = 0; $i < 10; $i++) {
            $randstring = $characters[rand(0, strlen($characters))];
        }
        return $randstring;
    } 


//check id and create



  $id = $_POST['id'];
  include('auth.php');
  if ($id == $auth) {
       
        $user = $_POST['user'];
        $pass = $_POST['pass'];
        $path = "/opt/lampp/htdocs";
        $exist_us = scandir($path);
        foreach ($exist_us as $exit) {
           if ($exit == $user ) { 
            $rn = randomstring();
            $user .= $rn;} // if exit == use end 
        } //froeach end 
      mkdir($user);
      include('copy.php');
      $source = "/opt/lampp/htdocs/conf";
      $dist = "/opt/lampp/htdocs/$user";
      copy_check($source,$dist); 
    
//save password in data base
      $sql = "INSERT INTO `ser_ser` (`usr`, `pa_pa`, `id`, `encryption`) VALUES ('$user', '$pass', NULL, 'fdfdffdff');";
       mysqli_query($conn,$sql);
<h1> account was created </h1>
<form action="index.php">
   <input type="hidden" name="user" value="<?php echo $user; ?>">
   <input type="hidden" name="pass" value="<?php echo $passr; ?>">
   <input type="hidden" name="id" value="<?php echo $id; ?>">
   <input type="submit" value="go to dashboard">
</form>
      $chdir = scandir($dist);
foreach ($chdir as $ru) {
      copy_all("$source/$ru","$dist/$ru");
 }//chdir foreach end   



      ?> 

   
   
      

<?php  } // if id = use end 

else { //id invalid do something 
   echo "invalid access id";
      }
?>
