<?php 
include('config.php');
$id = $_POST['id'];
  include("auth.php");
 if ($auth == $id )
{   
   $user = $_POST['user'];
   $pass = $_POST['pass'];
   $result = mysqli_query($conn,"SELECT * 'ser_ser' ")

 while($acc_db = mysqli_fetch_assoc($result)): 
     if ($user == $acc_db['usr']) { $cuser='true';}//end user check 
     if ($cuser == 'true') {  if ($pass == $acc_db['pa_pa'] ) {$cpass = 'true';}  }//end of pass user true end
        

endwhile;

$site_list = scandir('/opt/lampp/htdocs/');

?> 

<html> 
<body> 
<header> <title> your site list </title> </header>
<div id="header"> <h1>scrip kiddies <?php echo $user;?> </h1> </div> 
<div id="site_list"> 
<ol> <?php 
foreach ($site_list as $site_result) { ?> 
<li class="site_class"> <a href="<?php echo $user/$site_result; ?>"><?php echo $site_result; ?> </a> <form action="view.php" method="post"> <input type="hidden" value="<?php echo $site_result; ?> <input type="submit" value="show pass"> </from> </li> 

<?php } ?> 
</ol> 

</div>
<?php



}//id check end 

else {  
 //id invalid do somethinxg 
 echo "invalid id " ;

?>

