<?php 
include('config.php');
$id = $_POST['id'];
  include("auth.php");
 if ($auth == $id )
{   $cuser = 'df';
    $cpass = 'df';
   $user = $_POST['user'];
   $pass = $_POST['pass'];
   $result = mysqli_query($conn,"SELECT * FROM ser_ser");

 while ($acc_db = mysqli_fetch_assoc($result) ): 
     if ($user == $acc_db['usr']) { $cuser='true';}//end user check 
     if ($cuser == 'true') {  if ($pass == $acc_db['pa_pa'] ) {$cpass = 'true';
                                                            
                                                                     
} //pass end 
 }//end of  user true end
endwhile;

$site_list = scandir("/opt/lampp/htdocs/$inp");

?> 

<html> 
<body> 
<header> <title> your site list </title> </header>
<div id="header"> <h1>username : <?php echo $user;?> <h1>passwrd : <?php echo $pass;?</h1> </div> 
<div id="site_list"> 
<?php 
if ($cpass == 'true'){
foreach ($site_list as $site_result) { ?> 
<div class="site_class"> <a href='<?php echo "$user/$site_result"; ?>'><?php echo $site_result; ?> </a> <form action="view.php" method="post"> <input name="site" type="hidden" value='<?php echo "$site_result"; ?>'> <input name="user" type="hidden" value='<?php echo "$user"; ?>'> <input name="pass" type="hidden" value='<?php echo "$pass"; ?>'> <input type="submit" value="show pass"> </from></div>  

<?php } } if ($cpass == 'df') {header("location : login.php"); } ?> 


</div>
<?php



}//id check end 

else {  
 //id invalid do somethinxg 
 echo "invalid id " ; }

?>

