<?php 
  $db_host = "127.0.0.1";
  $db_user ="root";
  $db_pass = "";
  $db_name ="hehe";

$conn = mysqli_connect($db_host,$db_user,$db_pass);
mysqli_select_db($conn,$db_name);
if ($conn) { 
             echo "hehe for config" ; }
else { 
   echo "<h1> ha ha </h1>";}
  ?>

