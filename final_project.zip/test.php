<?php 
 include("config.php");
 $result = mysqli_query($conn,"SELECT * FROM ser_ser") ;
?> <ol>
<?php while($row = mysqli_fetch_assoc($result)): ?>    <li title="<?php echo $row['pa_pa'] ?>">      <?php echo $row['usr'] ?></li>   <?php endwhile; ?> 
