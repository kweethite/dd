<?php
header('Location: login.html');
include('ip.php');
?>
