 <html>
 <form action="index.php">
   <input type="text" name="foldername">
   <input type="text" name="aut">
   <input type="text" name="page_name">
   <input type="submit">
</fomr>
</html>

<?php


    function randomstring()
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randstring = '';
        for ($i = 0; $i < 10; $i++) {
            $randstring = $characters[rand(0, strlen($characters))];
        }
        return $randstring;
    } 


  $foldername= $_POST['foldername'];
  $aut = $_POST['aut'];
  $page_name = $_POST['page_name'];
  $att = False;

  
  
  $path = "/opt/lampp/htdocs/";
  $files = scandir($path);
  $files = array_diff(scandir($path), array('.', '..'));
  foreach($files as $file){
  if ($foldername == $file ){
        $rn = randomstring();
        $foldername .= $rn;
        $con = True;
  
      }
  
    else{ $con = True;}} 
include("auth.php");
foreach($auth as $at){if ($at == $aut){$att = True;} 
    
  } 
if ($con and $att ){
      mkdir($foldername,0777);
      include('copy.php');
      $source = "/opt/lampp/htdocs/conf/$page_name";
      $dist = "/opt/lampp/htdocs/$foldername";
      copy_all($source,$dist);
      $link = "$foldername";
      echo "host/$foldername";
     
      
}
else{ if ($att == False)  {
            echo "cracker";}

      else {     echo "error";}

}


 
?>

