<?php 
  
function copy_all($source_dir, $destination_dir) 
{ 
  // Open the source folder / directory 
  $dir = opendir($source_dir);  

  // Create a destination folder / directory if not exist 
  @mkdir($destination_dir);  

  // Loop through the files in source directory 
  while($file = readdir($dir)) 
  {
    // Skip . and .. 
    if(($file != '.') && ($file != '..')) 
    {  
      // Check if it's folder / directory or file 
      if(is_dir($source_dir.'/'.$file))  
      {  
        // Recursively calling this function for sub directory  
        recursive_files_copy($source_dir.'/'.$file, $destination_dir.'/'.$file); 
      }  
      else 
      {  
        // Copying the files
        copy($source_dir.'/'.$file, $destination_dir.'/'.$file);  
      }  
    }  
  }  

  closedir($dir); 
}  
?>
